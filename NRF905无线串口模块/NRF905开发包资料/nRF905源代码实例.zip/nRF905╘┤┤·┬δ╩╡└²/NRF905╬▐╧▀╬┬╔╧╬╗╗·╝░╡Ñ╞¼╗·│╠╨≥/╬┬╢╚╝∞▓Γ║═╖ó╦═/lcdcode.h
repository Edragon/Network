extern unsigned char code fytootech[];
extern unsigned char code web[];
extern unsigned char code dqwd[];
extern unsigned char code wxzj[];

extern unsigned char code asc_code[];
extern unsigned char code dot[];

extern unsigned char code du[];