/****************************************************************************
 **             - IO_def.h -
 **
 **     ϵͳӲ�����Զ��岿�֣�
 **			cpu���� IO�ܽŶ���
 **     ϵͳʱ�ӵ�
 **
 **    	 www.fytoo.com
 **     File version: $2008.2.1$
 **
 ***************************************************************************/
 
 
#ifndef IO_def_h
#define IO_def_h
#include <reg52.h> 
#include <intrins.h>

sfr P4    = 0xC0;
sfr WDT_CONTR =0XC1;

#define uint32_t unsigned long int
#define uint16_t unsigned int
#define uint8_t unsigned char

#define xtal	11

sbit DQ = P2^7;
sbit BELL =P4^0;
// Һ���ܽ�
sbit LCD_12864s_CS1 =P1^4;
sbit LCD_12864s_RES =P1^3;
sbit LCD_12864s_A0P=P1^2;
sbit LCD_12864s_WR =P1^1;//д
sbit LCD_12864s_RD =P1^0;//��
#define LCD_12864s_DB          P0
#define LCD_12864s_DB_PIN      P0


#define BYTE_BIT0	0x01
#define BYTE_BIT1	0x02
#define BYTE_BIT2	0x04
#define BYTE_BIT3	0x08
#define BYTE_BIT4	0x10
#define BYTE_BIT5	0x20
#define BYTE_BIT6	0x40
#define BYTE_BIT7	0x80


/*******************************************************************************************/
//���ÿڶ���//
sbit	TXEN=P3^5;
sbit	TRX_CE=P3^6;
sbit	PWR=P3^7;
sbit	MISO=P2^3;
sbit	MOSI=P2^4;
sbit	SCK=P2^5;
sbit	CSN=P2^6;
/////////////////////////////////////////////////////
sbit	AM=P2^2;
sbit	DR=P3^3;
sbit	CD=P2^1;
///////////////////////////////////////////////////////

sbit    LED1    =P1^7;
sbit    LED2    =P1^6;

sbit    KEY1    =P3^2;
sbit    KEY2    =P1^5;


#endif  //IO_def_h

