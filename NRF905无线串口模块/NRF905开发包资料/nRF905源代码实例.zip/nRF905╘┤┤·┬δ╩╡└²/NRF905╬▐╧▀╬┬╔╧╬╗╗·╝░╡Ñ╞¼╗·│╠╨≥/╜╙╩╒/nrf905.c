#include <reg52.h>
#include <ABSACC.h>
#include <intrins.h>
#include <stdio.h>
#include <io_def.h>

#define uint unsigned int                     //0 ~ 255
#define uchar unsigned char
/////////////////
#define BYTE_BIT0	0x01
#define BYTE_BIT1	0x02
#define BYTE_BIT2	0x04
#define BYTE_BIT3	0x08
#define BYTE_BIT4	0x10
#define BYTE_BIT5	0x20
#define BYTE_BIT6	0x40
#define BYTE_BIT7	0x80
////////////////
#define WC		0x00
#define RC		0x10
#define WTP		0x20
#define RTP		0x21
#define WTA		0x22
#define RTA		0x23
#define RRP		0x24
bdata unsigned  char DATA_BUF;
#define DATA7	((DATA_BUF&BYTE_BIT7) != 0)
#define DATA0   ((DATA_BUF&BYTE_BIT0) != 0)
sbit	flag	=DATA_BUF^7;
sbit	flag1	=DATA_BUF^0;
#define TxRxBuf_Len 32
unsigned char TxRxBuffer[TxRxBuf_Len];


//RF�Ĵ�������//
unsigned char idata RFConf[11]=
{
  0x00,                             //��������//
  0x4c,0x0c,0x44,0x04,0x04,0xcc,0xcc,0xcc,0xcc,0x58,                            //CRC������8λCRCУ�飬�ⲿʱ���źŲ�ʹ�ܣ�16M����
};
bit lcdbit;
///////////80us��ʱ/////////////////
void Delay(uchar n)
{
	uint k;
	while(n--)
	for(k=0;k<80;k++);
}

void Delaynop(void)
{
    unsigned char i;
	for(i=0;i<10;i++);
}

///////////////
unsigned char SpiRead(void)
{
	unsigned char j;
	for (j=0;j<8;j++)
	{
        DATA_BUF=DATA_BUF<<1;
		SCK=1;
		Delaynop();
		if (MISO)	//��ȡ���λ����������ĩβ��ͨ������λ��������ֽ�
		{
			DATA_BUF|=BYTE_BIT0;
		}
		else
		{
			DATA_BUF&=~BYTE_BIT0;
		}
		SCK=0;
		Delaynop();
	 }
	 return DATA_BUF;
}

void SpiWrite(unsigned char send)
{
	unsigned char i;
	DATA_BUF=send;
	for (i=0;i<8;i++)
	{
		if (DATA7)	//���Ƿ������λ
		{
			MOSI=1;
		}
		else
		{
			MOSI=0;
		}
		SCK=1;
		Delaynop();
		DATA_BUF=DATA_BUF<<1;
		SCK=0;
		Delaynop();
	}
}


////////////////��ʼ��nRF905///////////////////
void nRF905Init(void)
{
    CSN=1;						// Spi 	disable
	SCK=0;						// Spi clock line init low
	DR=0;						// Init DR for input
	AM=0;						// Init AM for input
	CD=0;						// Init CD for input
	PWR=1;					// nRF905 power on
	TRX_CE=0;					// Set nRF905 in standby mode
	TXEN=0;					// set radio in Rx mode
}

////////��ʼ���Ĵ���
void Config905(void)
{
	uchar i;
	CSN=0;						// Spi enable for write a spi command
	//SpiWrite(WC);				// Write config commandд����������
	for (i=0;i<11;i++)	// Write configration words  д��������
	{
	   SpiWrite(RFConf[i]);
	}
	CSN=1;					// Disable Spi
}


void SetRxMode(void)
{
	TXEN=0;
	TRX_CE=1;
	Delay(1); 					// delay for mode change(>=650us)
}

unsigned char CheckDR(void)		//����Ƿ��������ݴ��� Data Ready
{
	if (DR=1&&TRX_CE==1 && TXEN==0)
	{
       // Delay(50)  ;
		return 1;
	}
	else
	{
		return 0;
	}
}

void RxPacket(unsigned char *TxRxBuffer)
{
	uchar i;
    Delay(1);
//	TRX_CE=0;					// Set nRF905 in standby mode
    Delay(100);
    TRX_CE=0;
	CSN=0;						// Spi enable for write a spi command
    Delay(1);
	SpiWrite(RRP);
  // Delay(10000);
   // Delay(10000);			// Read payload command
	for (i = 0 ;i < 4 ;i++)
	{      // Delay(10000);
          //   Delay(10000);
          //   Delay(10000);
         //    Delay(10000); 
		TxRxBuffer[i]=SpiRead();		// Read data and save to buffer
           // Delay(10000);
            //    Delay(10000);
            //    Delay(10000);         
	}
	CSN=1;
          Delay(10);
		// Delay(10);
	TRX_CE=1;							
}
////////////////
void  RX(unsigned char *TxRxBuf)	 
{
          SetRxMode();			// Set nRF905 in Rx mode
		  //Delay(10000);
//          while (CheckDR()==0);
         //Delay(10000);
		 if( CheckDR()==1)
		   {
		     Delay(10);
	  	     RxPacket(TxRxBuf);
		    }
         //Delay(10000);			// Recive data by nRF905
		  Delay(10);
}



