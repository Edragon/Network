#include <reg52.h>
#include <intrins.h>
#include "DS18B20.h"
#include "nRF905.h"

unsigned char ten;
unsigned char bflag;//ָʾ�Ƿ���Ҫ��������

#define TxRxBuf_Len 4
unsigned char TxRxBuf[TxRxBuf_Len];	


void UART_init()
{
	SCON = 0x50;       /* uart in mode 1 (8 bit), REN=1 */
	TMOD = TMOD | 0x20 ;         /* Timer 1 in mode 2 */
	TH1  = 0xFD;                 /* 9600 Bds at 11.059MHz */
	TL1  = 0xFD;        /* 9600 Bds at 11.059MHz */
	//IE =0x90;
	TR1 = 1;                     /* Timer 1 run */
}

void Sendchar(unsigned char c)
{
	SBUF=c;                                     
	while(TI==0);                                               
	TI=0;
}

void print_string(unsigned char* p)
{
while(*p !='\0')
{
  Sendchar(*p++);
}
}



void main()
{
 
    unsigned char i,integer,decimal;
    BELL = 1;
    LED1 = 0;
	LED2 = 0;
	
	UART_init();

    nRF905Init();
    Config905();
	
    BELL = 0;	
	LED1 = 1;
	LED2 = 1;

	while (1)
	{
	    
		RX(TxRxBuf);
		Delay(3);
		CSN=1;	
		for(i=0;i<4;i++)
		{
	//	Delay(1000);
 		  if(TxRxBuf[0]==0x93)
		  {
	          BELL=1;
			  LED1=0;
		      LED2=0;

     		  print_string("receieve data is: ");
    		  Sendchar(TxRxBuf[1]);
    		  Sendchar('\r');
    		  Sendchar('\n');
		  }

		Delay(5);
	    LED1=1;
		LED2=1;
		BELL=0;
		TxRxBuf[0]=0xff;

//		R_S_Byte(TxRxBuffer[i]);
	//	Delay(10);
		}
		CSN=1;
		Delay(1);

	
//		print_string("Current temperature: ");
//		Sendchar(integer/10 +'0');
//		Sendchar(integer%10 +'0');
//		Sendchar('.');
//		Sendchar(decimal/10 +'0');
//		Sendchar(decimal%10 +'0');
//		Sendchar('\r');
//		Sendchar('\n');


	}
	
}