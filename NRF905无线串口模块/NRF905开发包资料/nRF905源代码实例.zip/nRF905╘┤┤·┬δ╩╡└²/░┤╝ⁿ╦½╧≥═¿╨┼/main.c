#include <reg52.h>
#include <intrins.h>
#include "lcd_12864s_driver.h"
#include "DS18B20.h"
#include "lcdcode.h"
#include "nRF905.h"

unsigned char ten;
unsigned char bflag;//ָʾ�Ƿ���Ҫ��������

#define TxRxBuf_Len 4
unsigned char TxBuf[TxRxBuf_Len]=
{
0x29,0x30,0x31,0x32
};

unsigned char RxBuf[TxRxBuf_Len];

void UART_init()
{
	SCON = 0x50;       /* uart in mode 1 (8 bit), REN=1 */
	TMOD = TMOD | 0x20 ;         /* Timer 1 in mode 2 */
	TH1  = 0xFD;                 /* 9600 Bds at 11.059MHz */
	TL1  = 0xFD;        /* 9600 Bds at 11.059MHz */
	//IE =0x90;
	TR1 = 1;                     /* Timer 1 run */
}

void Sendchar(unsigned char c)
{
	SBUF=c;                                     
	while(TI==0);                                               
	TI=0;
}

void print_string(unsigned char* p)
{
while(*p !='\0')
{
  Sendchar(*p++);
}
}



void main()
{
    unsigned char i;
    BELL = 1;
	
	UART_init();
    Lcd12864sInitializtion();
	Lcd12864sCls();
    Lcd12864sBmpPrintf(0,0,fytootech);
	//Lcd12864sBmpPrintf(2,32,wxzj);
	Lcd12864sBmpPrintf(3,3,dqwd);

	Lcd12864sBmpPrintf(6,9,web);

    nRF905Init();
    Config905();
	Init_DS18B20();
	Adjust_res_18B20(0x3f);	  //0.25
	ReadTemperature();
	
    BELL = 0;	

	while (1)
	{
	    
	    //ReadTemperature();
		Init_DS18B20();
		WriteOneChar_18B20(0xCC); // ����������кŵĲ���
		WriteOneChar_18B20(0x44); // �����¶Ȫ�

        SetRxMode();
	    delay_ms(10);
		RX(RxBuf);
	    delay_ms(10);
		CSN=1;	

	//	Delay(1000);
 		  if(RxBuf[0]==0x29)
		  {
	          BELL=1;
			  LED1=0;
		      LED2=1;
			  delay_ms(50);
		  }
          else if(RxBuf[0]==0x92)
		  {
	          BELL=1;
			  LED1=1;
		      LED2=0;
			  delay_ms(50);		      
		   }
	    delay_ms(10);
	    LED1=1;
		LED2=1;
		BELL=0;
		RxBuf[0]=0xff;
		if(KEY1==0)
		{
		    delay_ms(20);

			if(KEY1==0)
			  {
			   LED1 =0;
			   BELL =0;
			   bflag =1;
			   TxBuf[0]=0x29;
			   }
		}
		if(KEY2==0)
		{
		    delay_ms(20);
			if(KEY2==0)
			{			
			  LED2 =0;
			  BELL =0;
		      bflag =1;
			  TxBuf[0]=0x92;
			 }
		}
	
		delay_ms(10);
		LED2 =1;
		LED1 =1;
		BELL =0;

		if(bflag==1)
		{
			bflag =0;

//		    	TX(TxRxBuf);
			   
    			SetTxMode();
    			TxPacket(TxBuf);
				delay_ms(2);
    			SetTxMode();
    			TxPacket(TxBuf);
//			SetRxMode();
		}


		//ȡ�¶�
		Init_DS18B20();
		WriteOneChar_18B20(0xCC); //����������кŵĲ���
		WriteOneChar_18B20(0xBE); //��ȡ�¶ȼĴ���
		
		tempL=ReadOneChar_18B20(); //�����¶ȵĵ�λLSB
		tempH=ReadOneChar_18B20(); //�����¶ȵĸ�λMSB 
		
		if(tempH>0x7f)      //���λΪ1ʱ�¶��Ǹ�
		{
		tempL=~tempL;         //����ת����ȡ����һ
		tempH=~tempH+1;       
		fg=0;      //��ȡ�¶�Ϊ��ʱfg=0
		}
		integer = tempL/16+tempH*16;      //��������
		decimal1 = (tempL&0x0f)*10/16; //С����һλ
		decimal2 = (tempL&0x0f)*100/16%10;//С���ڶ�λ
		decimal=decimal1*10+decimal2; //С�����
		TxBuf[2]=integer;
		TxBuf[3]=decimal;
	

		//Lcd12864sBmpPrintf(3,9,dqwd);
		ten = integer/10;
		Lcd12864sAscPrintf(3,74,asc_code+16*'0'-32*16+16*ten);
		ten  =	integer-ten*10;
		Lcd12864sAscPrintf(3,82,asc_code+16*'0'-32*16+16*ten);
		Lcd12864sAscPrintf(3,90,dot);

		ten = decimal/10;
		Lcd12864sAscPrintf(3,98,asc_code+16*'0'-32*16+16*ten);
		ten  =	decimal-ten*10;
		Lcd12864sAscPrintf(3,106,asc_code+16*'0'-32*16+16*ten);
		Lcd12864sBmpPrintf(3,114,du);

	}
	
}