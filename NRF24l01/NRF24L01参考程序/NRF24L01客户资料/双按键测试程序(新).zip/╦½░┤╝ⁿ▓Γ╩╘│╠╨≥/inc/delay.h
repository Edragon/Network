/****************************************Copyright (c)**************************************************
**                               Guangzhou ZHIYUAN electronics Co.,LTD.
**                                     
**                                 http://www.embedtools.com
**
**--------------File Info-------------------------------------------------------------------------------
** File Name:         
** Last modified Date: 
** Last Version:       v1.00
** Description:        
** 
**------------------------------------------------------------------------------------------------------
** Created By:         
** Created date:       
** Version:            v1.00
** Descriptions:
**
**------------------------------------------------------------------------------------------------------
** Modified by:        
** Modified date:       
** Version:             
** Description:        
**
********************************************************************************************************/
#ifndef __DELAY_H
#define __DELAY_H
#include "typedef.h"

void _delay_us(unsigned int _us);
void Delay100ms(void);

#endif


