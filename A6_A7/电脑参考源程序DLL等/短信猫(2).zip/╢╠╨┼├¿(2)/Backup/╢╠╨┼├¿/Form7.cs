﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace 短信猫
{
    public partial class Form7 : Form
    {
        public Form7()
        {
            InitializeComponent();
        }
    }
}
