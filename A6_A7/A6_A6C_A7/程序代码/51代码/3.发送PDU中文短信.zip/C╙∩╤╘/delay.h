
#ifndef	__DELAY_H
#define	__DELAY_H

#include	"STC15Fxxxx.H"

extern u8 count_20ms;

void  delay_ms(u16 ms);


#endif
