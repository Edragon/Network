#ifndef	__UART1_H
#define	__UART1_H
#include	"STC15Fxxxx.H"
#define uchar unsigned char
void UART1_SendString(char *s);
void USART1_Init(void);


#endif
